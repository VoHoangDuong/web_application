create definer = root@localhost view tinh_trang as
select `classicmodels`.`customers`.`city` AS `city`, `classicmodels`.`customers`.`state` AS `state`
from `classicmodels`.`customers`;

