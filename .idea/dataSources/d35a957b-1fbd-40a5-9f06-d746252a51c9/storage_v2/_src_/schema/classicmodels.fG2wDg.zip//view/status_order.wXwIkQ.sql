create view status_order as
select `classicmodels`.`orders`.`orderNumber`   AS `orderNumber`,
       `classicmodels`.`orders`.`status`        AS `status`,
       count(`classicmodels`.`orders`.`status`) AS `So_luong`
from `classicmodels`.`orders`
group by `classicmodels`.`orders`.`status`
having (0 <> count(`classicmodels`.`orders`.`status`))
order by `So_luong`;

